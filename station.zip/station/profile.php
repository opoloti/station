<?php

    session_start();
    require 'includes/dbh.inc.php';
    
    define('TITLE',"Profile | petrolstation");
    
    if(!isset($_SESSION['userId']))
    {
        header("Location: login.php");
        exit();
    }
    
    if(isset($_GET['id']))
    {
        $userid = $_GET['id'];
    }
    else
    {
        $userid = $_SESSION['userId'];
    }
    
    $sql = "select * from users where idUsers = ".$userid;
    $stmt = mysqli_stmt_init($conn);    
    
    if (!mysqli_stmt_prepare($stmt, $sql))
    {
        die('SQL error');
    }
    else
    {
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);
    }
    
    include 'includes/HTML-head.php';   
?> 
</head>

<body>

    <?php include 'includes/navbar.php'; ?>
      <div class="container">
        <div class="row">
          <div class="col-sm-3">
            
              <?php include 'includes/profile-card.php'; ?>
              
          </div>
            
            
          <div class="col-sm-8 text-center" id="user-section">
              <img class="cover-img" src="img/4.jpg">
              <img class="profile-img" src="uploads/<?php echo $user['userImg']; ?>">
            
              
              <h2><?php echo ucwords($user['uidUsers']); ?></h2>
              <h6><?php echo ucwords($user['f_name']) . " " . ucwords($user['l_name']); ?></h6>
              <h6><?php echo '<small class="text-muted">'.$user['emailUsers'].'</small>'; ?></h6>
              
              <?php 
                if ($user['gender'] == 'm')
                {
                    echo '<i class="fa fa-male fa-2x" aria-hidden="true" style="color: #709fea;"></i>';
                }
                else if ($user['gender'] == 'f')
                {
                    echo '<i class="fa fa-female fa-2x" aria-hidden="true" style="color: #FFA6F5;"></i>';
                }
                ?>
             
              <div class="profile-bio">
                  <small><?php echo $user['bio'];?></small>
              </div>
          
          </div>
          <div class="col-sm-1">
            
          </div>
        </div>


      </div> <!-- /container -->
</body>