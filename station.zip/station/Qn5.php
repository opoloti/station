
<?php

    session_start();
    define('TITLE'," | petrol station");
    
    include 'includes/HTML-head.php';
    include 'includes/email-server.php';
?>  

	<link rel="stylesheet" type="text/css" href="css/contact-util.css">
	<link rel="stylesheet" type="text/css" href="css/contact-main.css">
</head>
    
<body>


	<div class="container-contact100">
		
			

			<div class="contact100-more flex-col-c-m" style="background-image: url('img/9.jpg');">
				<div class="flex-w size1 p-b-47">
					<div class="txt1 p-r-25">
						<span class="lnr lnr-map-marker"></span>
					</div>

					<div class="flex-col size2">
						<span class="txt1 p-b-20">
							We have come to the end.
						</span>

						<span class="txt2">
                                                   Thank you for your time  and cooperation<br>
                                                    your input is valued.
						</span>
					</div>
				</div>

				<div class="dis-flex size1 p-b-47">
					<div class="txt1 p-r-25">
						<span class="lnr lnr-phone-handset"></span>
					</div>

					<div class="flex-col size2">
						
						<span class="txt3">
							Good bye
						</span>
					</div>

                    <div class="container-contact100-form-btn">
                                    
                                    <a class="contact100-form-btn" href="Qn4.php"> To previous Page</a>
                                                        
                                    </div>
			 </div>

				


		
			</div>
		</div>
	</div>

<body>