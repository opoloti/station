
<!DOCTYPE html>
<html>
    <head>
        <meta name="description" content="A petrol station Website" />
        
  
        <title><?php echo TITLE; ?></title>
        
        <link href="css/bootstrap.min.css" rel="stylesheet"> 
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet"> 
        <link href="css/styles.css" rel="stylesheet">
        
        
        
        <link rel="shortcut icon" href="img/fuel.gif" />