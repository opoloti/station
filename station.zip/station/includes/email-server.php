<?php

$SMTPuser = 'fuel@gmail.com';   
$SMTPpwd = 'dingydingdong69dingydong'; 
$SMTPtitle = "petrolstation inc.";
$Domain = 'localhost';

