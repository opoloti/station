
 <?php

    session_start();
    include_once 'includes/dbh.inc.php';
    define('TITLE',"Dashboard| petrol station");

       
    function strip_bad_chars( $input ){
        $output = preg_replace( "/[^a-zA-Z0-9_-]/", "", $input);
        return $output;
    }
    
    if(!isset($_SESSION['userId']))
    {
        header("Location: login.php");
        exit();
    }
    
    include 'includes/HTML-head.php';
?> 
       
        <link href="css/loader.css" rel="stylesheet">


    </head>
    
    <body onload="pageLoad()" class="bridge">
        
        <div id="loader-wrapper">
        <img src='img/9.jpg' id='loader-logo'>
            <div class="loader">
                <div class="loader__bar"></div>
                <div class="loader__bar"></div>
                <div class="loader__bar"></div>
                <div class="loader__bar"></div>
                <div class="loader__bar"></div>
                <div class="loader__ball"></div>
            </div>
        </div>
        
        <div id="content" style="display: none">
            
            <?php include 'includes/navbar.php'; ?> 
            
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-3" >
                      </div>

                    <div class="col-sm-7" >

                        <div class="text-center p-3">
                            <h2 class='text-muted'>Welcome to Petrol station service Dashboard</h2>
                        </div>

                        <div class="tab-content" id="myTabContent">

                            <div class="tab-pane fade show active" id="forum" role="tabpanel" aria-labelledby="forum-tab">

                                
                <!-- begin script -->
             <div class='card card-profile text-center'>
                      <img alt='' class='card-img-top card-user-cover' src='img/fuel.gif'>
                    <a href='profile.php'>
                        <img src='uploads/<?php echo $_SESSION["userImg"] ?>' class='card-img-profile'>
                    </a>
                   
                    <a href="edit-profile.php">
                        <i class="fa fa-pencil fa-2x edit-profile" aria-hidden="true"></i>
                    </a>
                    
                    <h7>my name is Agent Steve <br>
                    Am I speaking to Mr./Mrs./Miss.</h7>
                    
             <h4 class='card-title'>
                   
                            <?php echo ucwords($_SESSION['f_name']." ".$_SESSION['l_name']); ?>


                 <!-- lets look at checkbox options -->
                          <br/><br/>
                 <div class="checkbox-animated my-4">
                  <input id="checkbox_animated_1" type="checkbox" name="subscribe1" value="subscribe1"> 
                    <label for="checkbox_animated_1">
                        <span class="check"></span>
                        <span class="box"></span>
                       YES
                    </label>

                    <div class="checkbox-animated my-4">
                     <input id="checkbox_animated_2" type="checkbox" name="subscribe2" value="subscribe2">
                     <label for="checkbox_animated_2">
                        <span class="check"></span>
                        <span class="box"></span>
                        NO
                    </label>
                    </div>
                </div>
             </h4>
            
            </div>
            <small class="d-block text-right mt-3">
                          <a href="Qn2.php" class="btn btn-primary">ticked yes proceed here</a>
                          <br/><br/>
                          <a href="Qn5.php" class="btn btn-primary">ticked No proceed here</a>
                      </small>

         </div>
            
            
            <!--end script-->

                               </div>

                            </div>

                            </div>                     

                    </div>
                </div>
            </div>
           
        </div>
             
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js" ></script>

        <script>
            var myVar;

            function pageLoad() {
              myVar = setTimeout(showPage, 4000);
            }

            function showPage() {
              document.getElementById("loader-wrapper").style.display = "none";
              document.getElementById("content").style.display = "block";
            }
        </script>  
        
    </body>
</html>