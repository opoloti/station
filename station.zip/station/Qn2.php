
<?php

    session_start();
    define('TITLE'," | petrol station");
    
    include 'includes/HTML-head.php';
    
?>  

	<link rel="stylesheet" type="text/css" href="css/contact-util.css">
	<link rel="stylesheet" type="text/css" href="css/contact-main.css">
</head>
    
<body>

    
    <?php
    
        if(isset($_SESSION['userId']))
        {
            include 'includes/navbar.php';
        }
        
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\Exception; 
        
        require 'PHPMailer/src/Exception.php';
        require 'PHPMailer/src/PHPMailer.php';  
        require 'PHPMailer/src/SMTP.php';
        
        
        // check for header injection
        function has_header_injection($str){
            return preg_match('/[\r\n]/',$str);
        }
    
        if (isset($_POST['contact_submit'])){
            
            
            
            if(!isset($_SESSION['userId']))
            {
                $email = trim($_POST['email']);
                $name = trim($_POST['first-name']).' '.trim($_POST['last-name']);
            }
            else
            {
                $email = trim($_SESSION['emailUsers']);
                $name = 'User: '.$_SESSION['userUid'];
            }
            
            $msg = $_POST['message'];
            
            
            if (has_header_injection($name) || has_header_injection($email)){
                die(); 
            }
            
            
            
            $to = $email;
            
            $subject = "$name sent you a message via your contact form";
           
            if (isset($_POST['subscribe']))
            {
                $message .= "<br><br><br>"
                            . "<strong>IMPORTANT:</strong> Please add <i>$email</i> "
                            . "to your mailing list.<br>";
            }
            
            
            $mail = new PHPMailer(true);            
            
            try {
                $mail->isSMTP();                                      
                $mail->Host = 'smtp.gmail.com';                      
                $mail->SMTPAuth = true;                              
                $mail->Username = $SMTPuser;                              
                $mail->Password = $SMTPpwd;             
                $mail->SMTPSecure = 'tls';                           
                $mail->Port = 587;                                    
                
                //Recipients
                $mail->setFrom($to, $SMTPtitle);
                $mail->addAddress($SMTPuser, $SMTPtitle);     

                //Content
                $mail->isHTML(true);                                  
                $mail->Subject = $subject;
                $mail->Body    = $message;
 
                $mail->send();
            } 
            catch (Exception $e) {
                echo '<h4 class="error">Message could not be sent. Mailer Error: '. $mail->ErrorInfo
                        .'</h4>';
            }
        }
    ?>

	<div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" method="post" action="">
				
      <label class="label-input100" for="message">What petrol station do you like?</label>
     <!-- listing the petrol stations -->
                                <div class="checkbox-animated my-4">
                                    <input id="checkbox_animated_1" type="checkbox" name="subscribe1" value="subscribe1">
                                    <label for="checkbox_animated_1">
                                        <span class="check"></span>
                                        <span class="box"></span>
                                       Total
                                    </label>

                                    <div class="checkbox-animated my-4">
                                    <input id="checkbox_animated_2" type="checkbox" name="subscribe2" value="subscribe2">
                                    <label for="checkbox_animated_2">
                                        <span class="check"></span>
                                        <span class="box"></span>
                                        Shell
                                    </label>
                                    </div>
                                    
                                    <div class="checkbox-animated my-4">
                                      <input id="checkbox_animated_3" type="checkbox" name="subscribe3" value="subscribe3">
                                      <label for="checkbox_animated_3">
                                        <span class="check"></span>
                                        <span class="box"></span>
                                        Stabex
                                      </label>
                                    </div>

                                </div>

                <div class="container-contact100-form-btn">
                                
                    <a class="contact100-form-btn" href="Qn3.php"> Go to Next Page</a>
                                
               </div>
      	      
               <div class="container-contact100-form-btn">
                                
                                <a class="contact100-form-btn" href="index.php"> Go to Previous Page</a>
                                            
                           </div>
                      
			</form>

            <div class="contact100-more flex-col-c-m" style="background-image: url('img/fuel.gif');">
            <div class="flex-w size1 p-b-47">
                <div class="txt1 p-r-25">
                    <span class="lnr lnr-map-marker"></span>
                </div>

                <div class="flex-col size2">
                    <span class="txt1 p-b-20">
                        About Us
                    </span>

                    <span class="txt3">
                                               petrol stations<br>
                                               customer services, Kampala Uganda
                    </span>
                </div>
            </div>

            <div class="dis-flex size1 p-b-47">
                <div class="txt1 p-r-25">
                    <span class="lnr lnr-phone-handset"></span>
                </div>

            </div>

            <div class="dis-flex size1 p-b-47">
                <div class="txt1 p-r-25">
                    <span class="lnr lnr-envelope"></span>
                </div>

                <div class="flex-col size2">
                    <span class="txt1 p-b-20">
                        General Support
                    </span>

                    <span class="txt3">
                        fuel@outlook.com
                    </span>
                </div>
            </div>
                       
        </div>
    </div>
</div>

</body>